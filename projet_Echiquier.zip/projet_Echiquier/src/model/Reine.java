package model;

public class Reine {

	public boolean move(int xFinal,int yFinal) {
		return true;
	}
	
	public boolean isMoveOk(int xFinal,int yFinal) {
		return true;
	}
	
}
