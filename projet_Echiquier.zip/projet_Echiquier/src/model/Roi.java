package model;

public class Roi {
	public boolean move(int xFinal,int yFinal) {
		return true;
	}
	
	public boolean isMoveOk(int xFinal,int yFinal) {
		return true;
	}
	
}
