package model;

public class Jeu {

}
