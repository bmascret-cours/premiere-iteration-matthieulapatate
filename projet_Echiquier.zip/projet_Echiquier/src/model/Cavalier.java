package model;

public class Cavalier {

}
