package model;

public class Fou {

}
