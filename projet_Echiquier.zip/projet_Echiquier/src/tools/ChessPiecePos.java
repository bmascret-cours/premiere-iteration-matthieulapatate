package tools;

public enum ChessPiecePos {

}
